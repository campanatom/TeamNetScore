package it.unibo.teamnetscore.controller.interfaces;

public interface IEventiAllenatore {

}
