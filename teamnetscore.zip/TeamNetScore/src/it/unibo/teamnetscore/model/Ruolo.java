package it.unibo.teamnetscore.model;

public enum Ruolo {
    ALLENATORE,
    CALCIATORE
}
