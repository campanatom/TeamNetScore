package it.unibo.teamnetscore.model;

public enum TipoEvento {
	PARTITA,
	ALLENAMENTO,
	CENA_DI_SQUADRA;
}
